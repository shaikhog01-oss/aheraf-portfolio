AHERAF SHAIKH PORTFOLIO

GitHub Pages upload:
1. Create a public GitHub repository.
2. Upload index.html to the repository.
3. Go to Settings > Pages.
4. Choose Deploy from a branch.
5. Select main and /(root), then Save.
6. GitHub will provide your public website URL.

The website is already named index.html so GitHub Pages can open it directly.
